import os
DB_USER = "root"
DB_PASS = "fritoure"
DB_HOST = "127.0.0.1"
DB_PORT = 3306
DB_NAME = "ai_doc_manager"

DATABASE_URI = f"mysql+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

MODEL_NAME = 'paraphrase-multilingual-mpnet-base-v2'
FAISS_INDEX_DIR = "faiss_indices"

UPLOAD_FOLDER = 'uploaded_docs'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'docx', 'md'}

os.makedirs(FAISS_INDEX_DIR, exist_ok=True)
os.makedirs(UPLOAD_FOLDER, exist_ok=True)