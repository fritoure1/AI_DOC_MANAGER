from app.services.nlp_service import SemanticSearchService

nlp_service = SemanticSearchService()