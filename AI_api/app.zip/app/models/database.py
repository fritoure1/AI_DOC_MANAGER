from sqlalchemy import create_engine, text
from app.config import DATABASE_URI

db_engine = create_engine(DATABASE_URI)

def get_db_connection():
    return db_engine

def insert_doc(user_id: int, file_name: str, file_path: str, doc_type: str) -> int:

    with db_engine.connect() as conn:
        result = conn.execute(
            text(
                """
                INSERT INTO DOCUMENTS (user_id, file_name, file_path, doc_type)
                VALUES (:user_id, :file_name, :file_path, :doc_type)
                """
            ),
            {
                "user_id": user_id,
                "file_name": file_name,
                "file_path": file_path,
                "doc_type": doc_type
            }
        )
        conn.commit()
        return result.lastrowid

def create_chunk(document_id: int, chunk_index: int, content: str) -> int:

    with db_engine.connect() as conn:
        result = conn.execute(
            text(
                """
                INSERT INTO DOCUMENT_CHUNKS (document_id, chunk_index, content)
                VALUES (:doc_id, :index, :content)
                """
            ),
            {"doc_id": document_id, "index": chunk_index, "content": content}
        )
        conn.commit()
        return result.lastrowid

def create_faiss_mapping(user_id: int, faiss_index_id: int, chunk_id: int):

    with db_engine.connect() as conn:
        conn.execute(
            text(
                """
                INSERT INTO FAISS_MAP (user_id, faiss_index_id, chunk_id)
                VALUES (:user_id, :faiss_id, :chunk_id)
                """
            ),
            {"user_id": user_id, "faiss_id": faiss_index_id, "chunk_id": chunk_id}
        )
        conn.commit()

def get_mappings_for_user(user_id: int)-> tuple[dict[int, int], dict[int, int]]:

    faiss_to_chunk = {}
    chunk_to_faiss = {}
    with db_engine.connect() as conn:
        result = conn.execute(
            text("SELECT faiss_index_id, chunk_id FROM FAISS_MAP WHERE user_id = :user_id"),
            {"user_id": user_id}
        )
        for row in result:
            faiss_to_chunk[row[0]] = row[1]
            chunk_to_faiss[row[1]] = row[0]
    return faiss_to_chunk, chunk_to_faiss

def get_document_by_name(user_id: int, file_name: str) -> dict | None:
    
    with db_engine.connect() as conn:
        result = conn.execute(
            text(
                """
                SELECT id, file_path FROM DOCUMENTS
                WHERE user_id = :user_id AND file_name = :file_name
                """
            ),
            {"user_id": user_id, "file_name": file_name}
        )
        row = result.fetchone() 
        if row:
            return row._asdict() 
        return None

def get_chunks_by_ids(chunk_ids: list[int]) -> list[dict[str, any]]:
    if not chunk_ids:
        return []
    placeholders = ', '.join([':id_' + str(i) for i in range(len(chunk_ids))])
    params = {'id_' + str(i): chunk_id for i, chunk_id in enumerate(chunk_ids)}

    query = text(
        f"""
        SELECT
            c.id as chunk_id,
            c.content,
            d.file_name,
            d.id as document_id
        FROM DOCUMENT_CHUNKS c
        JOIN DOCUMENTS d ON c.document_id = d.id
        WHERE c.id IN ({placeholders})
        """
    )

    results = []
    with db_engine.connect() as conn:
        db_result = conn.execute(query, params)
        for row in db_result.mappings():
            results.append(dict(row))

    ordered_results = sorted(results, key=lambda r: chunk_ids.index(r['chunk_id']))
    return ordered_results