import faiss
import numpy as np
import os
from sentence_transformers import SentenceTransformer
from langchain_text_splitters import RecursiveCharacterTextSplitter
import fitz
from docx import Document
from app.models import database
from app.config import MODEL_NAME, FAISS_INDEX_DIR

class SemanticSearchService:
    def __init__(self, model_name: str=MODEL_NAME):
        
        self.model = SentenceTransformer(model_name)
        self.dimension = self.model.get_sentence_embedding_dimension()
        print(f"Modèle chargé (dimension: {self.dimension}).")

        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len
        )

        self.indices: dict[int, faiss.Index] = {}
        self.faiss_to_chunk_map: dict[int, dict[int, int]] = {}
        self.chunk_to_faiss_map: dict[int, dict[int, int]] = {}
    
    def _get_faiss_index_path(self, user_id: int) -> str:
        return os.path.join(FAISS_INDEX_DIR, f"user_{user_id}.faiss")
    
    def _load_user_index(self, user_id: int)-> faiss.Index:
        if user_id in self.indices:
            return self.indices[user_id]

        index_path = self._get_faiss_index_path(user_id)

        try:
            if os.path.exists(index_path):
                print(f"Chargement de l'index FAISS pour user: {user_id} depuis {index_path}")
                index = faiss.read_index(index_path)
            else:
                print(f"Création d'un nouvel index FAISS pour user: {user_id}")
                index = faiss.IndexFlatL2(self.dimension)
        
            f_to_c, c_to_f =database.get_mappings_for_user(user_id)

            self.indices[user_id]= index
            self.faiss_to_chunk_map[user_id] = f_to_c
            self.chunk_to_faiss_map[user_id] = c_to_f

            return index
        except Exception as e:
            print(f"Erreur lors du chargement/création de l'index pour {user_id}: {e}")
            self.indices[user_id] = faiss.IndexFlatL2(self.dimension)
            self.faiss_to_chunk_map[user_id] = {}
            self.chunk_to_faiss_map[user_id] = {}
            return self.indices[user_id]
        
    def _save_user_index(self, user_id: int):
        if user_id in self.indices:
            index_path = self._get_faiss_index_path(user_id)
            print(f"Sauvegarde de l'index FAISS pour {user_id} sur {index_path}")
            faiss.write_index(self.indices[user_id], index_path)
    
    def _extract_text_from_pdf(self, file_path: str) -> str:
        """Utilise PyMuPDF (fitz) pour extraire le texte d'un PDF."""
        text = ""
        try:
            # fitz.open est la fonction clé de PyMuPDF
            with fitz.open(file_path) as doc:
                for page in doc:
                    # Ajoute le texte de la page, suivi d'un saut de ligne
                    text += page.get_text() + "\n" 
        except Exception as e:
            print(f"Erreur PyMuPDF lors de la lecture de {file_path}: {e}")
            return ""
        return text

    def _extract_text_from_docx(self, file_path: str) -> str:
        """Utilise python-docx pour extraire le texte d'un DOCX."""
        text = ""
        try:
            doc = Document(file_path)
            for para in doc.paragraphs:
                text += para.text + "\n"
        except Exception as e:
            print(f"Erreur python-docx lors de la lecture de {file_path}: {e}")
            return ""
        return text

    def _extract_text_from_txt(self, file_path: str) -> str:
        """Lecture simple pour les fichiers texte (TXT, MD, etc.)."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            print(f"Erreur lecture TXT de {file_path}: {e}")
            return ""

    def _read_document(self, file_path: str) -> str:
        """
        Lit le contenu d'un fichier en appelant le bon "parser"
        en fonction de son extension.
        Remplace l'ancienne logique 'unstructured'.
        """
        try:
            _, file_extension = os.path.splitext(file_path)
            file_extension = file_extension.lower() # Met en minuscule (ex: .PDF -> .pdf)

            if file_extension == '.pdf':
                print(f"Lecture (PyMuPDF) de: {file_path}")
                return self._extract_text_from_pdf(file_path)
            
            elif file_extension == '.docx':
                print(f"Lecture (python-docx) de: {file_path}")
                return self._extract_text_from_docx(file_path)
            
            elif file_extension in ['.txt', '.md']:
                print(f"Lecture (TXT) de: {file_path}")
                return self._extract_text_from_txt(file_path)
            
            else:
                print(f"AVERTISSEMENT: Type de fichier non supporté {file_extension}. Tentative de lecture TXT.")
                return self._extract_text_from_txt(file_path)

        except Exception as e:
            print(f"Erreur générale lors de _read_document pour {file_path}: {e}")
            return "" 
    def process_and_index_document(self, user_id: int, document_id: int, file_path: str) -> dict[str, any]:
        """Traite un document, le chunk, génère les embeddings et l'indexe."""
        print(f"Indexation du document {document_id} pour l'utilisateur {user_id}...")
        
        index = self._load_user_index(user_id)

        full_text = self._read_document(file_path)
        if not full_text:
            return {"status": "error", "message": "Impossible de lire le document."}

        chunks = self.text_splitter.split_text(full_text)
        print(f"Document découpé en {len(chunks)} chunks.")

        embeddings = self.model.encode(chunks, show_progress_bar=True)
        embeddings = np.asarray(embeddings, dtype=np.float32)

        faiss_ids_added = []
        for i, (chunk_text, embedding) in enumerate(zip(chunks, embeddings)):
            chunk_id = database.create_chunk(document_id, i, chunk_text)
            faiss_index_id = index.ntotal
            index.add(np.array([embedding]))

            database.create_faiss_mapping(user_id, faiss_index_id, chunk_id)
            self.faiss_to_chunk_map[user_id][faiss_index_id] = chunk_id
            self.chunk_to_faiss_map[user_id][chunk_id] = faiss_index_id
            
            faiss_ids_added.append(faiss_index_id)

        self._save_user_index(user_id)

        print(f"Indexation terminée. {len(chunks)} chunks ajoutés.")
        return {"status": "success", "chunks_indexed": len(chunks)}

    def search(self, user_id: int, query: str, k: int = 5) -> list[dict[str, any]]:
        """Effectue une recherche sémantique pour un utilisateur."""
        print(f"Recherche pour '{query}' (utilisateur {user_id})...")
        
        index = self._load_user_index(user_id)
        if index.ntotal == 0:
            print("Index vide pour cet utilisateur.")
            return []

        query_embedding = self.model.encode([query])
        query_embedding = np.asarray(query_embedding, dtype=np.float32)

        distances, faiss_indices = index.search(query_embedding, k)
        
        chunk_ids_to_fetch = []
        scores = {}
        DISTANCE_THRESHOLD = 1.2
        
        for i, faiss_idx in enumerate(faiss_indices[0]):
            score= float(distances[0][i])
            if score > DISTANCE_THRESHOLD or faiss_idx == -1: # FAISS retourne -1 s'il n'y a pas assez de résultats
                continue
                
            chunk_id = self.faiss_to_chunk_map[user_id].get(faiss_idx)
            if chunk_id:
                chunk_ids_to_fetch.append(chunk_id)
                scores[chunk_id] = float(distances[0][i]) # Stocke le score (distance)

        results_from_db = database.get_chunks_by_ids(chunk_ids_to_fetch)

        final_results = []
        for res in results_from_db:
            res['score'] = scores.get(res['chunk_id'])
            final_results.append(res)
            
        print(f"Recherche terminée. {len(final_results)} résultats trouvés.")
        return final_results