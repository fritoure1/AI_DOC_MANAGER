import axios from 'axios';

const PYTHON_API_URL = 'http://127.0.0.1:5001';

export const search = async (q: string, userId: number) => {
  if (!q) {
    throw new Error("Le paramètre 'q' est manquant.");
  }

  console.log(`[Electron Main] Recherche user ${userId}: "${q}"`);

  try {
    const pythonResponse = await axios.get(`${PYTHON_API_URL}/search`, {
      params: {
        q: q,
        user_id: userId
      }
    });

    return pythonResponse.data;

  } catch (error: any) {
    console.error("Erreur connexion Python:", error.message);
    throw new Error("Erreur lors de la recherche IA.");
  }
};