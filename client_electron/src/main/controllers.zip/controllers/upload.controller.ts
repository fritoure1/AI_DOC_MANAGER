import axios from 'axios';
import * as fileParser from '../services/file.parser';
import * as textSplitter from '../services/text.splitter';
import * as docModel from '../models/documents.model';

const PYTHON_API_URL = 'http://127.0.0.1:5001';

export const upload = async (filePath: string, userId: number) => {
  try {
    console.log(`Début du parsing pour : ${filePath}`)

    const {text, metadata} = await fileParser.parseFile(filePath);

    if (!text || text.trim().length === 0) {
      throw new Error("Fichier vide ou illisible.");
    }
    console.log(`Texte extrait: ${text.length} caractères`)

    const chunks = await textSplitter.splitText(text);
    console.log(`${chunks.length} fragments généné`);
    console.log( `Envoi des fragments a l'ia`);

    const pythonResponse = await axios.post(`${PYTHON_API_URL}/process_chunks`,{
      user_id: userId,
      filename: metadata.title,
      chunks: chunks,
      metadata: metadata
    });
    return pythonResponse.data;
    
  }catch (error: any){
    console.error("Erreur Upload Controller : ",error.message);
    if (error.response){
      throw new Error(`Erreur Python: ${JSON.stringify(error.response.data)}`)
    }
    throw error;
  }
}

    