import prisma from '../database/prisma.ts'

export const findAllByUser = async (userId: bigint | number) => {
  return await prisma.dOCUMENTS.findMany({
    where: { 
      user_id: userId 
    },
    orderBy: { 
      created_at: 'desc' 
    },
    include: {
      DOCUMENT_TAGS: {
        include: { TAGS: true }
      },
      _count: {
        select: { DOCUMENT_CHUNKS: true }
      }
    }
  });
};
export const findById = async (docId: bigint | number) => {
  return await prisma.dOCUMENTS.findUnique({
    where: { id: docId }
  });
};

export const deleteById = async (docId: bigint | number) => {
  return await prisma.dOCUMENTS.delete({
    where: { id: docId }
  });
};