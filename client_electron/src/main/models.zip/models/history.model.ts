import prisma from '../database/prisma';

export const getUserHistory = async (userId: number | bigint) => {
  return await prisma.sEARCHES.findMany({
    where: {
      user_id: BigInt(userId)
    },
    orderBy: {
      created_at: 'desc'
    },
    include: {
      SEARCH_RESULTS: {
        include: {
          DOCUMENT_CHUNKS: {
            include: {
              DOCUMENTS: {
                select: { file_name: true }
              }
            }
          }
        },
        orderBy: {
          rank_pos: 'asc'
        }
      }
    },
    take: 20
  });
};